/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5;

/**
 *
 * @author user
 */

public class Main {
    public static void main(String[] args) {
        System.out.println("===== INFO HEWAN =====");
        
        System.out.println ();
        Kucing kucing = new Kucing("Mimi");
        kucing.tampilkanInfo();
        kucing.suara();

        System.out.println ();
        Anjing anjing = new Anjing("Momo");
        anjing.tampilkanInfo();
        anjing.suara();
        
        System.out.println ();
        
        System.out.println("\n===== INFO KENDARAAN =====");
        
        System.out.println ();
        
        Mobil mobil = new Mobil();
        mobil.nama = "Avanza";
        mobil.kecepatan = 120;
        mobil.jumlahPintu = 4;
        mobil.tampilkanInfo();
        mobil.tampilkanInfoMobil();
        
        System.out.println ();
        SepedaMotor motor = new SepedaMotor();
        motor.nama = "Ninja";
        motor.kecepatan = 180;
        motor.jenisMesin = "4-Tak";
        motor.tampilkanInfo();
    }
}