/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5;

/**
 *
 * @author user
 */
class Kucing extends Hewan {
    public Kucing(String nama) {
        super(nama, "Kucing");
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Kucing bernama " + nama + " (jenis: " + jenis + ").");
    }

    @Override
    public void suara() {
        System.out.println(nama + " berbunyi: Meong~");
    }
}
