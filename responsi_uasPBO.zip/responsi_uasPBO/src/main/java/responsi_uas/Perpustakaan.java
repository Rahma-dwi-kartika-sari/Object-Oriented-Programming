/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsi_uas;

/**
 *
 * @author user
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Perpustakaan implements Serializable {

    private List<Buku> daftarBuku;
    private List<Anggota> daftarAnggota;
    private List<Peminjaman> daftarPeminjaman;

    public Perpustakaan() {
        daftarBuku = new ArrayList<>();
        daftarAnggota = new ArrayList<>();
        daftarPeminjaman = new ArrayList<>();
    }

    public void tambahBuku(Buku b) {
        daftarBuku.add(b);
    }

    public void tambahAnggota(Anggota a) {
        daftarAnggota.add(a);
    }

    public List<Buku> getDaftarBuku() {
        return daftarBuku;
    }

    public List<Anggota> getDaftarAnggota() {
        return daftarAnggota;
    }

    public List<Peminjaman> getDaftarPeminjaman() {
        return daftarPeminjaman;
    }

    public Buku cariBuku(String id) {
        for (Buku b : daftarBuku) {
            if (b.getId().equals(id)) return b;
        }
        return null;
    }

    public Anggota cariAnggota(String id) {
        for (Anggota a : daftarAnggota) {
            if (a.getId().equals(id)) return a;
        }
        return null;
    }

    public Peminjaman cariPeminjaman(String idAnggota) {
        for (Peminjaman p : daftarPeminjaman) {
            if (p.getAnggota().getId().equals(idAnggota)) return p;
        }
        return null;
    }

    public void simpanData() {
        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream("data_perpustakaan.ser"))) {
            oos.writeObject(this);
            System.out.println("Data berhasil disimpan.");
        } catch (IOException e) {
            System.out.println("Gagal menyimpan data.");
        }
    }

    public static Perpustakaan bacaData() {
        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream("data_perpustakaan.ser"))) {
            return (Perpustakaan) ois.readObject();
        } catch (Exception e) {
            System.out.println("Data belum ada, membuat data baru.");
            return new Perpustakaan();
        }
    }
}
