/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsi_uas;

/**
 *
 * @author user
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Perpustakaan p = Perpustakaan.bacaData();
        int pilih;

        do {
            System.out.println("\n=== MENU PERPUSTAKAAN DIGITAL ===");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Lihat Buku");
            System.out.println("3. Tambah Anggota");
            System.out.println("4. Lihat Anggota");
            System.out.println("5. Pinjam Buku");
            System.out.println("6. Kembalikan Buku");
            System.out.println("7. Lihat Peminjaman");
            System.out.println("8. Simpan Data");
            System.out.println("0. Keluar");
            System.out.print("Pilih: ");

            try {
                pilih = input.nextInt();
                input.nextLine();

                switch (pilih) {
                    case 1:
                        System.out.print("ID Buku: ");
                        String id = input.nextLine();
                        System.out.print("Judul: ");
                        String judul = input.nextLine();
                        System.out.print("Penulis: ");
                        String penulis = input.nextLine();

                        p.tambahBuku(new Buku(id, judul, penulis));
                        break;

                    case 2:
                        for (Buku b : p.getDaftarBuku()) {
                            b.tampilInfo();
                            System.out.println("----------------");
                        }
                        break;

                    case 3:
                        System.out.print("ID Anggota: ");
                        String ida = input.nextLine();
                        System.out.print("Nama: ");
                        String nama = input.nextLine();

                        p.tambahAnggota(new Anggota(ida, nama));
                        break;

                    case 4:
                        for (Anggota a : p.getDaftarAnggota()) {
                            System.out.println(a.getId() + " - " + a.getNama());
                        }
                        break;

                    case 5:
                        System.out.print("ID Anggota: ");
                        String idAng = input.nextLine();
                        Anggota agt = p.cariAnggota(idAng);
                        if (agt == null) break;

                        System.out.print("ID Buku: ");
                        Buku bk = p.cariBuku(input.nextLine());
                        if (bk == null) break;

                        Peminjaman pj = p.cariPeminjaman(idAng);
                        if (pj == null) {
                            pj = new Peminjaman(agt);
                            p.getDaftarPeminjaman().add(pj);
                        }
                        pj.pinjamBuku(bk);
                        break;

                    case 6:
                        System.out.print("ID Anggota: ");
                        Peminjaman pin = p.cariPeminjaman(input.nextLine());
                        if (pin != null) {
                            System.out.print("ID Buku: ");
                            pin.kembalikanBuku(input.nextLine());
                        }
                        break;

                    case 7:
                        for (Peminjaman x : p.getDaftarPeminjaman()) {
                            x.tampilPeminjaman();
                        }
                        break;

                    case 8:
                        p.simpanData();
                        break;

                    case 0:
                        System.out.println("Program selesai.");
                        break;

                    default:
                        System.out.println("Pilihan tidak valid.");
                }
            } catch (Exception e) {
                System.out.println("Input tidak valid.");
                input.nextLine();
                pilih = -1;
            }

        } while (pilih != 0);
    }
}
