/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsi_uas;

/**
 *
 * @author user
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Peminjaman implements LayananPeminjaman, Serializable {

    private Anggota anggota;
    private List<Buku> daftarBuku;

    public Peminjaman(Anggota anggota) {
        this.anggota = anggota;
        this.daftarBuku = new ArrayList<>();
    }

    public Anggota getAnggota() {
        return anggota;
    }

    @Override
    public void pinjamBuku(Buku buku) {
        daftarBuku.add(buku);
        System.out.println("Buku berhasil dipinjam.");
    }

    @Override
    public void kembalikanBuku(String idBuku) {
        for (int i = 0; i < daftarBuku.size(); i++) {
            if (daftarBuku.get(i).getId().equals(idBuku)) {
                daftarBuku.remove(i);
                System.out.println("Buku berhasil dikembalikan.");
                return;
            }
        }
        System.out.println("Buku tidak ditemukan dalam peminjaman.");
    }

    public void tampilPeminjaman() {
        System.out.println("Peminjam: " + anggota.getNama());
        for (Buku b : daftarBuku) {
            b.tampilInfo();
            System.out.println("------------------");
        }
    }
}
