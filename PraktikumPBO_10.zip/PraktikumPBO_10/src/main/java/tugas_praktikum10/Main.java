/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum10;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        Pembayaran elektronik = new Elektronik();
        Pembayaran makanan = new Makanan();

        double hargaElektronik = 2000000;
        double hargaMakanan = 50000;

        double pajakElektronik = elektronik.hitungPajak(hargaElektronik);
        double pajakMakanan = makanan.hitungPajak(hargaMakanan);

        System.out.println("Sistem Pembayaran Toko:");
        System.out.println("Harga Elektronik : Rp" + hargaElektronik);
        System.out.println("Pajak (10%)      : Rp" + pajakElektronik);
        System.out.println("Total Bayar      : Rp" + (hargaElektronik + pajakElektronik));
        System.out.println();
        System.out.println("Harga Makanan    : Rp" + hargaMakanan);
        System.out.println("Pajak (5%)       : Rp" + pajakMakanan);
        System.out.println("Total Bayar      : Rp" + (hargaMakanan + pajakMakanan));
    }
}
