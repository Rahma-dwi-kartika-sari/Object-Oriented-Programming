/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tugas_praktikum10;

/**
 *
 * @author user
 */
public interface Pembayaran {
    double hitungPajak(double harga);
}
