/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum11;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        Buku novel = new Buku("Laskar Pelangi");
        Buku fiksi = new Buku("Filosofi Teras");
        Buku nonFiksi = new Buku("Clean Code");

        Perpustakaan perpustakaan = new Perpustakaan();
        
        perpustakaan.tambahBuku(novel);
        perpustakaan.tambahBuku(fiksi);
        perpustakaan.tambahBuku(nonFiksi);

        System.out.println("Perpustakaan");
        perpustakaan.infoPerpustakaan();
    }
}
