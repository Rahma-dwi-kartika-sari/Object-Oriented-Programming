/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspraktikum6;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja();

        Produk buku = new Buku("Cara cepat menguasai bahasa Jerman", 100000);
        Produk hp = new Elektronik("Tablet", 7000000);
        Produk baju = new Pakaian("Cardigan rajut", 300000);

        keranjang.tambahProduk(buku);
        keranjang.tambahProduk(hp);
        keranjang.tambahProduk(baju);

        keranjang.tampilkanProduk();

        System.out.println("Total Harga Setelah Diskon: Rp" + keranjang.hitungTotal());
    }
}
