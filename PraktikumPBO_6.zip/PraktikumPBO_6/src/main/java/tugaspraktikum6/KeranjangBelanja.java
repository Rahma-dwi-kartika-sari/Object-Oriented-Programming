/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspraktikum6;

/**
 *
 * @author user
 */
import java.util.ArrayList;

class KeranjangBelanja {
    private ArrayList<Produk> daftarProduk = new ArrayList<>();

    public void tambahProduk(Produk p) {
        daftarProduk.add(p);
    }

    public double hitungTotal() {
        double total = 0;
        for (Produk p : daftarProduk) {
            double diskon = p.hitungDiskon();
            total += (p.harga - diskon);
        }
        return total;
    }

    public void tampilkanProduk() {
        for (Produk p : daftarProduk) {
            p.tampilkanInfo();
            System.out.println("Diskon: Rp" + p.hitungDiskon());
            System.out.println("Harga setelah diskon: Rp" + (p.harga - p.hitungDiskon()));
            System.out.println("---------------------------------");
        }
    }
}
