/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pbo_teori4;

/**
 *
 * @author user
 */
public class PBO_Teori4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
