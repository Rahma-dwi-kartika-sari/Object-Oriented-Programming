/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teori4;

/**
 *
 * @author user
 */
public class Mahasiswa {
    private String nama;
    protected int umur;
    public String npm;
    String jurusan;

    public Mahasiswa(String nama, int umur, String npm, String jurusan) {
        this.nama = nama;
        this.umur = umur;
        this.npm = npm;
        this.jurusan = jurusan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
}
