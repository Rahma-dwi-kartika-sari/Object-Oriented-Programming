/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teori4;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        MahasiswaBaru mhsBaru = new MahasiswaBaru(
            "Rahma", 18, "2410506008", "Teknologi Informasi", "SMK N 2 Magelang"
        );

        System.out.println("=== Data Awal ===");
        mhsBaru.tampilkanInfo();

        mhsBaru.setNama("Dwi");
        mhsBaru.umur = 19;
        mhsBaru.npm = "2410506009";
        mhsBaru.jurusan = "Sistem Informasi";

        System.out.println("\n=== Data Setelah Diedit ===");
        mhsBaru.tampilkanInfo();
    }
}

