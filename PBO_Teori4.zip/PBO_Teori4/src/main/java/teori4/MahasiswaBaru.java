/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teori4;

/**
 *
 * @author user
 */
class MahasiswaBaru extends Mahasiswa {
    private final String asalSekolah;

    public MahasiswaBaru(String nama, int umur, String npm, String jurusan, String asalSekolah) {
        super(nama, umur, npm, jurusan);
        this.asalSekolah = asalSekolah;
    }

    public void tampilkanInfo() {
        System.out.println("Nama: " + getNama());
        System.out.println("Umur: " + umur);
        System.out.println("NPM: " + npm);
        System.out.println("Jurusan: " + jurusan);
        System.out.println("Asal Sekolah: " + asalSekolah);
    }
}
