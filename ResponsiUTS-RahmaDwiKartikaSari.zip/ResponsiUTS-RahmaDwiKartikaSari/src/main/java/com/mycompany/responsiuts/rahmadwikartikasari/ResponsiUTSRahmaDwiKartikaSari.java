/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.responsiuts.rahmadwikartikasari;

/**
 *
 * @author user
 */
public class ResponsiUTSRahmaDwiKartikaSari {
    public static void main(String[] args) {
        // Objek Produk
        Produk produk1 = new Elektronik("Laptop", 15000000, 2);
        Produk produk2 = new Makanan("Snack", 8000, "2023-12-30");

        // Objek Pegawai 
        Pegawai pegawai1 = new PegawaiTetap("Rahma", 5000000, 1000000);
        Pegawai pegawai2 = new PegawaiKontrak("Dwi", 3000000, 12);

        // Output Produk
        System.out.println("=== Output Produk ===");
        produk1.tampilkanInfo();
        

        // Output Pegawai
        System.out.println("=== Output Pegawai ===");
        pegawai1.tampilkanInfo();
        
        //Output Polimorfisme
        System.out.println("=== Output Polimorfisme ===");
        produk2.tampilkanInfo();
        pegawai2.tampilkanInfo();
    }
}
